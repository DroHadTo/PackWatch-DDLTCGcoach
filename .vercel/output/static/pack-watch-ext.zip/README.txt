Pack Watch live overlay — Chrome / Edge / Brave
================================================

This version WATCHES the play tab.

1. Unzip this folder (it must contain manifest.json).
2. chrome://extensions → Developer mode ON.
3. Remove any old Pack Watch, then Load unpacked → this folder.
4. Open https://ddltcg.com/play and RELOAD the page.
5. A live panel appears top-right: snapshot of the tab, updating HP/turn/advice, and a Tell me box.

If the panel is missing, reload the match. It never clicks for you.

Wayne is banned from online lists. Advice only.
